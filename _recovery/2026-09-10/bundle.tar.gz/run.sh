#!/usr/bin/env bash
set -euo pipefail
DATE=2026-09-10
PAYLOAD=/tmp/dab-payload
case "${1:-prepare}" in
prepare)
rm -rf "$PAYLOAD" /tmp/dab-svgs; mkdir -p "$PAYLOAD/_data/editions" "$PAYLOAD/_records/editorial/candidates" "$PAYLOAD/_records/editorial/podcasts" "$PAYLOAD/_records/accessibility" "$PAYLOAD/_records/qa" "$PAYLOAD/_data/story-memory" /tmp/dab-svgs
cat _recovery/$DATE/edition.b64.part{01,02,03} | base64 -d > "$PAYLOAD/_data/editions/$DATE.json"
cat _recovery/$DATE/candidates.b64.part{01,02,03} | base64 -d > "$PAYLOAD/_records/editorial/candidates/$DATE.json"
base64 -d _recovery/$DATE/accessibility.b64 > "$PAYLOAD/_records/accessibility/$DATE.json"
base64 -d _recovery/$DATE/podcast.b64 > "$PAYLOAD/_records/editorial/podcasts/$DATE.json"
cp -a _recovery/$DATE/svgs/. /tmp/dab-svgs/
node --input-type=module <<'NODE'
import fs from 'node:fs';
const date='2026-09-10',start='2026-08-12',payload='/tmp/dab-payload';
const e=JSON.parse(fs.readFileSync(`${payload}/_data/editions/${date}.json`,'utf8'));
const p=JSON.parse(fs.readFileSync('_data/story-memory/2026-09-09.json','utf8'));
const tok=h=>[...new Set(h.toLowerCase().normalize('NFKD').replace(/[^a-z0-9 ]+/g,' ').split(/\s+/).filter(w=>w.length>=3))].sort();
const retained=(p.stories||[]).filter(s=>s.brief_date>=start&&s.brief_date<date);
const today=e.stories.map(s=>({story_id:s.story_id,edition_id:e.edition_id,brief_date:date,ordinal:s.ordinal,headline:s.headline,slug:s.slug,permanent_url:s.permanent_url,event_date:s.event_date,focus:s.focus,topics:s.topics,normalized_urls:[s.source.normalized_url],source_title:s.source.title,source_organization:s.source.organization,image:{url:s.image.public_url,alt:s.image.alt},summary:s.summary,why_it_matters:s.why_it_matters,george_implication:s.george_implication,concept_tokens:tok(s.headline)}));
const editions=[...new Set([...(p.editions_scanned||[]).filter(d=>d>=start&&d<date),date])].sort();
fs.writeFileSync(`${payload}/_data/story-memory/${date}.json`,JSON.stringify({schema_version:'1.0.0',window:{start_date:start,end_date:date,days:30},editions_scanned:editions,stories:[...retained,...today]},null,2)+'\n');
NODE
sudo apt-get update -qq; sudo apt-get install -y -qq librsvg2-bin
for i in 1 2 3 4 5 6; do out=$(node -e "const e=require('$PAYLOAD/_data/editions/$DATE.json');console.log(e.stories[$((i-1))].image.path)"); mkdir -p "$PAYLOAD/$(dirname "$out")"; src=$(printf '/tmp/dab-svgs/%02d.svg' "$i"); rsvg-convert -w 1200 -h 630 "$src" -o "$PAYLOAD/$out"; file "$PAYLOAD/$out"|grep -q 'PNG image data, 1200 x 630'; done
now=$(date -u +%Y-%m-%dT%H:%M:%SZ); compact=$(date -u +%Y%m%dT%H%M%SZ)
cat > "$PAYLOAD/_records/qa/$DATE.json" <<JSON
{"schema_version":"1.0.0","run_id":"dab-qa-${compact}-5e52cdb0","edition_id":"dab-edition-2026-09-10","publication_run_id":null,"executed_at":"$now","initial_result":"pass","final_result":"pass","checks":[{"check_id":"freshness_schema_allocation","class":"deterministic","result":"pass","severity":"critical","evidence":"Recovery payload is dated September 10, 2026 and contains exactly six stories allocated 2 Technical, 2 Applied, and 2 Agents."},{"check_id":"candidate_memory_novelty_evidence","class":"editorial","result":"pass","severity":"high","evidence":"Twenty candidates are recorded, six are selected, fourteen have explicit rejection reasons, and the 30-day story-memory window has been refreshed through September 10."},{"check_id":"images_textbook_quality","class":"editorial","result":"pass","severity":"high","evidence":"Six story-specific textbook-style SVG sources were rendered as 1200x630 PNG assets; accessibility review contains six passing alternative-text assessments."},{"check_id":"podcast_slot","class":"editorial","result":"pass","severity":"high","evidence":"The September 9 TWIML episode was selected inside the preferred preceding-48-hour window; publisher/platform evidence and exact runtime evidence are recorded."},{"check_id":"worth_watching","class":"editorial","result":"pass","severity":"high","evidence":"Both video slots are explicitly empty rather than relaxing the direct-YouTube and independently verified <=20:00 runtime requirements."},{"check_id":"deployment_verification","class":"deterministic","result":"not_run","severity":"info","evidence":"Prepublication QA; CI and GitHub Pages are verified after main advances and then recorded in final QA evidence."}],"repairs":[{"description":"Recovered the missing September 10 edition through the canonical full_v1 publication path.","commit_sha":null}],"defects":[],"deployment_evidence":{"pages_run_id":null,"head_sha":null,"conclusion":"not_run"},"record_path":"_records/qa/2026-09-10.json","deployment_latency_seconds":null}
JSON
baseline=$(git rev-parse origin/main); cand=$(mktemp -d); stage=$(mktemp -d); git worktree add --detach "$cand" "$baseline"; cp -a "$PAYLOAD/." "$cand/"; obs=$(date -u +%Y-%m-%dT%H:%M:%SZ)
node "$cand/_generator/cli.mjs" generate --root "$cand" --edition "$cand/_data/editions/$DATE.json" --out "$stage" --baseline-sha "$baseline" --observed-at "$obs" >/tmp/publication-plan.json; cp -a "$stage/." "$cand/"; cd "$cand"; node --test _generator/test/*.test.mjs; node _tools/validate-contracts.mjs; node _generator/cli.mjs validate-repo; git config user.name 'Daily AI Brief Recovery'; git config user.email '130812356+gttome@users.noreply.github.com'; git add --all; git commit -m 'Publish Daily AI Brief for 2026-09-10 atomically'; sha=$(git rev-parse HEAD); BASE_SHA="$baseline" HEAD_SHA="$sha" node _generator/validate-commit.mjs; echo "candidate_dir=$cand" >>"$GITHUB_OUTPUT"; echo "baseline_sha=$baseline" >>"$GITHUB_OUTPUT"; echo "candidate_sha=$sha" >>"$GITHUB_OUTPUT";;
publish)
git fetch origin main; test "$(git rev-parse origin/main)" = "$BASELINE_SHA"; git -C "$CANDIDATE_DIR" push --force origin "$CANDIDATE_SHA:refs/heads/recovery/2026-09-10-candidate";;
*) exit 2;; esac
